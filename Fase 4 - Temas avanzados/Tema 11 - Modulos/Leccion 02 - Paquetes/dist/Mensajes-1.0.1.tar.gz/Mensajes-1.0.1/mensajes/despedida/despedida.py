def despedir():
    print("Adiós, me despido desde despedida.despedida()")


class Despedida:
    def __init__(self) -> None:
        print("Adiós, me despido desde despedida.__init__()")