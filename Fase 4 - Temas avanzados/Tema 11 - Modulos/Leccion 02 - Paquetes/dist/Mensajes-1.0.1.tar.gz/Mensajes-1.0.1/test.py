# import saludos
# from saludos import *
from mensajes.bienvenida.saludos import saludar, Saludo
from mensajes.despedida.despedida import *
# saludos.saludar()
saludar()
Saludo()

despedir()
Despedida()